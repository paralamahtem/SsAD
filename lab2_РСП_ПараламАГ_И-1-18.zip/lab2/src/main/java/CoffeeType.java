public enum CoffeeType {
    GRAIN,GROUND,SOLUBLE;
}
